<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Forgot Password</title>
</head>
<body>
   
    <b><p>Please click on the link below to reset your password</p></b>
    <a href="http://localhost:3000/resetpassword/{{ $token }}">Click here to reset password</a>
    <p>Thank You</p>
</body>
</html>
